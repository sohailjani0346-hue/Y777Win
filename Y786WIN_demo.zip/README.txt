# Y786WIN Demo
Static demo/play-money gaming website.
Open index.html in a browser, or upload the folder to a static web host.
It intentionally does not contain real-money betting, deposits, withdrawals, or gambling payments.
